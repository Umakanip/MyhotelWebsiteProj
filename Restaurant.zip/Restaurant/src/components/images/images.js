import Cauliflower from "../../images/1cauliflower.png";
import Deliciousfood from "../../images/Pngtree-delicious-food.png";
import Lettuce from "../../images/1pngtree—lettuce.png";
import UserPic from "../../images/userpic.png";
import Wondon from "../../images/the-wonton.png";
import FireWater from "../../images/fire-water.png";
import Secondham from "../../images/2ham-sandwich.png";
import Oneham from "../../images/1ham-sandwich.png";
import Threeham from "../../images/3ham-sandwich.png";
import Fourham from "../../images/4ham-sandwich.png";
import Fiveham from "../../images/5ham-sandwich.png";
import Sixham from "../../images/ham-sandwich.png";
import AppStore from "../../images/App_Store_Badge.png";
import FooterLeaf from "../../images/footer-leaf.png";
import AppScreen from "../../images/app-screen.png";
import GooglePlay from "../../images/google-play-badge.png";
import RedCarrotDown from "../../images/red-caret-down.svg";
import Logo from "../../images/logo.svg";
import Dots from "../../images/dots-bg.svg";
import Arrow2 from "../../images/arrow2.svg";
import Dotbg1 from "../../images/dots-bg1.svg";
import Arrow from "../../images/arrow.svg";

const MyImages = {
  Cauliflower,
  Deliciousfood,
  Lettuce,
  UserPic,
  RedCarrotDown,
  Logo,
  Dots,
  Wondon,
  FireWater,
  Arrow2,
  Oneham,
  Secondham,
  Threeham,
  Fourham,
  Fiveham,
  Sixham,
  AppScreen,
  AppStore,
  GooglePlay,
  Dotbg1,
  FooterLeaf,
  Arrow,
};

export default MyImages;
