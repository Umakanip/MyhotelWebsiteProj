import React from "react";

function MenuThree() {
  return (
    <div>
      <h1>This is a Menu three.</h1>
    </div>
  );
}
export default MenuThree;
