import React from "react";

function MenuFour() {
  return (
    <div>
      <h1>This is a Menu four.</h1>
    </div>
  );
}
export default MenuFour;
