import React from "react";

function MenuOne() {
  return (
    <div>
      <h1>This is a Menu one.</h1>
    </div>
  );
}
export default MenuOne;
