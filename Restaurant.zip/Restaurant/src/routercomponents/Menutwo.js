import React from "react";

function MenuTwo() {
  return (
    <div>
      <h1>This is a Menu two.</h1>
    </div>
  );
}
export default MenuTwo;
